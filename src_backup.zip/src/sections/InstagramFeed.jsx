import React from "react";

const InstagramFeed = () => {
  return (
    <div>
      <iframe
        src="https://widgets.sociablekit.com/instagram-reels/iframe/25610772"
        frameborder="0"
        width="100%"
        height="1000"
      ></iframe>
    </div>
  );
};

export default InstagramFeed;
